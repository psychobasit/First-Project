
import './App.css'

function App() {
 

  return (
    <div className='main'>
    <div className='a1' >
<img className='size ' src="https://m.media-amazon.com/images/M/MV5BMDRjYWI5NTMtZTYzZC00NTg4LWI3NjMtNmI3MTdhMWQ5MGJlXkEyXkFqcGdeQXVyNTg4MDc4Mg@@._V1_FMjpg_UX1000_.jpg"></img>

    </div>
    <div className='a2'>
    
   
      <p className='des all'>
        <h2 className='all'>Stranger Things Spot Light</h2>
        . 
        <p></p>
        In 1980s Indiana, a group of young friends witness supernatural forces and secret government exploits. As they search for answers, the children unravel a series of extraordinary mysteries
      </p>
    </div>
    
    

    </div>


    
  )
}

export default App
